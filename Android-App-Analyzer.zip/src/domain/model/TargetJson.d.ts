export interface TargetJson {
  appInfo: {
    packages: any[];
  };
}
