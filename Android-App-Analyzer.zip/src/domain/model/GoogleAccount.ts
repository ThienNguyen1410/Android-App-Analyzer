export interface GoogleAccount {
  username: string;
  password: string;
}
