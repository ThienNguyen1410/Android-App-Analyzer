export interface Device {
  isConnected: boolean;
}
