export interface APKID {
  scanDepthFive(path: string): Promise<string>;
}
