export const credential = {
  USERNAME: "tietaiyen@gmail.com",
  PASSWORD: "1234578aA",
  ANDROID_ID: "android.device.id",
  LANG_CODE: "en_US",
  LANG: "us",
};
