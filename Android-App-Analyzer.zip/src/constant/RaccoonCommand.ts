export const RaccoonCommand = {
  download: `java -jar ~/Android-App-Analyzer/extensions/raccoon-4.24.0.jar --gpa-download-dir ~/Android-App-Analyzer/apks --gpa-download `,
};
