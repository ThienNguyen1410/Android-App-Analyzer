export const DEV_NAME = {
  VNG: "VNG Corporation - Công ty Cổ phần VNG",
  ZALOPAY: "ZION JOINT STOCK COMPANY",
};
