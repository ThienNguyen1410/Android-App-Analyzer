// Enable discord bot
import "src/app/discord/bot";
