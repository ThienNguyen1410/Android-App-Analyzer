export const COLORS = {
  running: "#ffc72e",
  success: "#ADE792",
  error: "#ff0000",
};
